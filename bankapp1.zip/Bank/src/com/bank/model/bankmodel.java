//$Id$
package com.bank.model;

public class bankmodel {
	private String name;
	private String accounttype;
	private int samount;
	private String password;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	public int getSamount() {
		return samount;
	}
	public void setSamount(int samount) {
		this.samount = samount;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "bankmodel [name=" + name + ", accounttype=" + accounttype + ", samount=" + samount + "]";
	}
}
