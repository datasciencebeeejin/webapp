//$Id$
package com.bank.model;

public class DepositModel {
	protected Long accountno;
	protected int depamount;
	public Long getAccountno() {
		return accountno;
	}
	public void setAccountno(Long accountno) {
		this.accountno = accountno;
	}
	public int getDepamount() {
		return depamount;
	}
	public void setDepamount(int depamount) {
		this.depamount = depamount;
	}
	@Override
	public String toString() {
		return "DepositModel [accountno=" + accountno + ", depamount=" + depamount + "]";
	}
}
