//$Id$
package com.bank.model;

public class withdrawModel {
	private Long accountno;
	private String password;
	private int withdrawAmount;
	public Long getAccountno() {
		return accountno;
	}
	public void setAccountno(Long accountno) {
		this.accountno = accountno;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getWithdrawAmount() {
		return withdrawAmount;
	}
	public void setWithdrawAmount(int withdrawAmount) {
		this.withdrawAmount = withdrawAmount;
	}
	@Override
	public String toString() {
		return "withdrawModel [accountno=" + accountno + ", password=" + password + ", withdrawAmount=" + withdrawAmount + "]";
	}
	

}
