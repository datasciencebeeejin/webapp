//$Id$
package com.bank.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bank.model.withdrawModel;
import com.bank.controller.*;
public class withdrawDao {
	   int k;
	public int withdradata(withdrawModel wm) throws ClassNotFoundException, SQLException {
		Class.forName("org.postgresql.Driver");
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bankaccount","berjin","blue");
		PreparedStatement prep=con.prepareStatement("update accountdetails set samount=samount-? where accountno=? and samount>=? and password=?");
		prep.setInt(1,wm.getWithdrawAmount());
		prep.setLong(2, wm.getAccountno());
		prep.setInt(3, wm.getWithdrawAmount());
		prep.setString(4,wm.getPassword());
        k=prep.executeUpdate();
		System.out.println(k+" rows affected");
		if(k<1) {
			System.out.println("NOTHING HAPPENS");
		}
		else {
			System.out.println("COMPLETED");
		}
		return k;
		}
	}
