//$Id$
package com.bank.dao;
import java.sql.*;

import com.bank.model.loginModel;

public class loginDao {
	public int logindata(loginModel lm) throws ClassNotFoundException, SQLException{
		Class.forName("org.postgresql.Driver");
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bankaccount","berjin","blue");
	    PreparedStatement stm=con.prepareStatement("Select * from accountdetails where accountno=? and password=?");
	    stm.setLong(1,lm.getAccountno());
	    stm.setString(2,lm.getPassword());
        ResultSet rSet =stm.executeQuery();
        int size = 0;
        while (rSet.next()){
            size++;
        }
        return size;
	    
	}


}
