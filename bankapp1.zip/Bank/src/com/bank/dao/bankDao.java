package com.bank.dao;
import com.bank.model.*;
import java.sql.*;
public class bankDao {
	public void detailInsert(bankmodel root) throws ClassNotFoundException, SQLException {
		Class.forName("org.postgresql.Driver");
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bankaccount","berjin","blue");
		PreparedStatement prep=con.prepareStatement("insert into accountdetails(name,accounttype,samount,password) values(?,?,?,?)");
		prep.setString(1,root.getName());
		prep.setString(2, root.getAccounttype());
        prep.setInt(3, root.getSamount());
        prep.setString(4,root.getPassword());
        int i=prep.executeUpdate();  
        System.out.println(i+" records affected"); 
        con.close();
        
	}

}
