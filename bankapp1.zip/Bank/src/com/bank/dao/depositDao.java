//$Id$
package com.bank.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.RowSet;

import com.bank.model.DepositModel;
import com.bank.model.bankmodel;

public class depositDao {
	public int depositupdate(DepositModel dm) throws ClassNotFoundException, SQLException {
		Class.forName("org.postgresql.Driver");
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bankaccount","berjin","blue");
		PreparedStatement prep=con.prepareStatement("update accountdetails set samount=samount+? where accountno=?");
		prep.setInt(1,dm.getDepamount());
		prep.setLong(2, dm.getAccountno());
		int j=prep.executeUpdate();
		
		System.out.println(j +" rows affected");
		if(j<1) {
			System.out.println("NOTHING HAPPENS");
		}
		else {
			System.out.println("COMPLETED");
		}
		return j;
    }
}
