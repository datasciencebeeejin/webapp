//$Id$
package com.bank.login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/logout")
public class accountLogout extends HttpServlet{
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		session.removeAttribute("accountno");
		session.removeAttribute("password");
		response.setHeader("Cache-Control","no-cache, no-store");
		if(session.getAttribute("accountno") == null){
			RequestDispatcher rDispatcher=request.getRequestDispatcher("login.jsp");
			rDispatcher.forward(request, response);
			
		}
		
		
	}
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
		doPost(request, response);
	}

}
