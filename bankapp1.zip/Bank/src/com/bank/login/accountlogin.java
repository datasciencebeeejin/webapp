//$Id$
package com.bank.login;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bank.dao.loginDao;
import com.bank.model.loginModel;
@WebServlet("/login")
public class accountlogin extends HttpServlet{
	public void doPost(HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException {
		Long accountno=Long.parseLong(request.getParameter("accountno"));
		String password =request.getParameter("password").toString();
		loginModel lmd = new loginModel();
		lmd.setAccountno(accountno);
		lmd.setPassword(password);
		loginDao lDao =new loginDao();
		try {
			if(lDao.logindata(lmd)==1) {
				HttpSession session=request.getSession();
				session.setAttribute("accountno",accountno);
				session.setAttribute("password", password);
			    RequestDispatcher rDispatcher =request.getRequestDispatcher("MainPage.jsp");
			    rDispatcher.forward(request, response);
			}
			else {
				RequestDispatcher rDispatcher =request.getRequestDispatcher("login.jsp?success=unsuccess");
			    rDispatcher.forward(request, response);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
