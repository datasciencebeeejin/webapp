//$Id$
package com.bank.controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bank.dao.withdrawDao;
import com.bank.model.withdrawModel;
import com.bank.dao.*;
public class withdrawController extends HttpServlet{
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		response.setContentType("text/html");
		HttpSession session=request.getSession();
		String acno=session.getAttribute("accountno").toString();
	    Long accountno=Long.parseLong(acno);
		String password =request.getParameter("password").toString();
		int withdrawAmount = Integer.parseInt(request.getParameter("withdrawAmount"));
		withdrawModel objwithdraw =new withdrawModel();
		objwithdraw.setAccountno(accountno);
		objwithdraw.setPassword(password);
		objwithdraw.setWithdrawAmount(withdrawAmount);
		withdrawDao objWithdrawDao = new withdrawDao();
		try {
			if(objWithdrawDao.withdradata(objwithdraw )==1) {
				RequestDispatcher rd=request.getRequestDispatcher("WithdrawMoney.jsp?success=success");
				rd.forward(request, response);
			}
			else {
				RequestDispatcher rd=request.getRequestDispatcher("WithdrawMoney.jsp?success=unsuccess");
			    rd.forward(request, response);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}   
	

}
