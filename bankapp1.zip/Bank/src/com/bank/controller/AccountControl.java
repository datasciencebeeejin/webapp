package com.bank.controller;
import com.bank.dao.*;
import com.bank.model.*;

import jdk.nashorn.internal.runtime.ECMAErrors;
import sun.nio.cs.US_ASCII;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Enumeration;

import javax.el.ELContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.el.ExpressionEvaluator;
import javax.servlet.jsp.el.VariableResolver;
public class AccountControl extends HttpServlet {
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		response.setContentType("text/html");
		HttpSession session=request.getSession();
		String name=request.getParameter("name").toString();
        String accounttype=request.getParameter("accounttype").toString();
        int samount=Integer.parseInt(request.getParameter("samount"));
        String password=request.getParameter("password").toString();
        bankmodel objbm=new bankmodel();
        objbm.setAccounttype(accounttype);
        objbm.setName(name);
        objbm.setSamount(samount);
        objbm.setPassword(password);
		bankDao objBankDao=new bankDao();
		try {
			objBankDao.detailInsert(objbm);
			session.setAttribute("created","created");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		RequestDispatcher rDispatcher =request.getRequestDispatcher("AccountCreation.jsp?success=success");
		rDispatcher.forward(request, response);
}
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
		doPost(request, response);
	}


}
