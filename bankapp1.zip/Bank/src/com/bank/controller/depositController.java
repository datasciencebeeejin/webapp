//$Id$
package com.bank.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.dao.depositDao;
import com.bank.model.DepositModel;


public class depositController extends HttpServlet{
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		Long accountno=Long.parseLong(request.getParameter("accountno")); 
        int depamount=Integer.parseInt(request.getParameter("depamount"));
     
        DepositModel objDepositModel = new DepositModel();
        objDepositModel.setAccountno(accountno);
        objDepositModel.setDepamount(depamount);
		depositDao objdepositDao = new depositDao();
		try {
			if(objdepositDao.depositupdate(objDepositModel)==1){
				RequestDispatcher rd=request.getRequestDispatcher("depositMoney.jsp?success=success");
				rd.forward(request, response);
			}
			else {
				RequestDispatcher rd=request.getRequestDispatcher("depositMoney.jsp?success=unsuccess");
				rd.forward(request, response);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
