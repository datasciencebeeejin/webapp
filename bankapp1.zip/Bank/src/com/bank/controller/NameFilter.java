package com.bank.controller;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class NameFilter implements Filter {

	public void destroy() {
		// TODO Auto-generated method stub
	}

	public void doFilter(ServletRequest req,ServletResponse res,FilterChain chain)throws IOException, ServletException{
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) res;
	    String name=request.getParameter("name").toLowerCase().toString();
        String name1=name.replaceAll("\\s+","a").trim();
        if(name1.replaceAll("[^a-z]","").length()!=(name).length() || name.length() >20 || name.length()<3){
        	System.out.println("WORKING on filter");
        	System.out.println(name1.replaceAll("[^a-z]",""));
        	RequestDispatcher rDispatcher=request.getRequestDispatcher("AccountCreation.jsp?success=unsuccess");
			rDispatcher.forward(request, response);
        }
        else {
            System.out.println("WORKING on AccountControl");
            chain.doFilter(request, response);
        }
	}


	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
